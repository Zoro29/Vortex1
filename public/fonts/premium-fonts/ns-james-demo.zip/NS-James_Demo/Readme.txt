Copyright (c) 2015,Nautica Studios
NS-James is the sole property of Nautica Studios and authored by Aritra Das.
Thank you for downloading the demo version!
Note:This includes a free weight ie NS-JamesLight of  the type family.The free weight is for demo purposes and is for personal use only.

Purchase the full family here for personal and commercial use:
https://gumroad.com/l/nsjames

View the full project here:
https://www.behance.net/gallery/42379081/NS-James-(Font-Family)