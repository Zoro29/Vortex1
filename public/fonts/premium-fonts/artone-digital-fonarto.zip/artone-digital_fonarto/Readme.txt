Fonarto and Fonarto XT font are freeware. This means that you can use it on your commercial or non-commercial works for free. But it would be great if you deside to donate for this font project.

If you wish to write to let me know how a certain font will be used, and for what purpose, send your e-mail to:
simple@artonedigital.com

Arwan Sutanto
ArtOne CreativeWorks
http://artonedigital.com

